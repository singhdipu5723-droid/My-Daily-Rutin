MY DAILY ROUTINE — Black + Fire Orange Starter Project
=================================

Is ZIP mein:
1) web/        Black + Fire Orange responsive web app + PWA (offline support)
2) android/    Android Studio WebView wrapper + native alarm receiver source

Six routine options included: Personal, Student, Job, Business, Fitness, Learning.

WEB APP CHALANE KA TARIKA
-------------------------
- web folder ko kisi static hosting par upload karein (HTTPS zaroori hai).
- Browser mein website kholein.
- Chrome menu > Add to Home screen / Install app.
- Pehli baar internet par kholne ke baad app files offline cache ho jayengi.

ANDROID APP BANANE KA TARIKA
---------------------------
- Android Studio install karein.
- android folder ko Open karein.
- Gradle sync hone dein.
- Build > Build Bundle(s) / APK(s) > Build APK(s).
- APK Android Studio ke app/build/outputs/apk/debug/ folder mein milega.

IMPORTANT LIMITATIONS
--------------------
- Is source project mein APK pehle se compile nahi kiya gaya hai.
- Android native alarm receiver exact alarm permission aur notification permission use karta hai.
  Android version/device ke hisaab se user ko permissions allow karni hongi.
- Web/PWA alarms browser notification permission par depend karte hain; browser band hone par
  har device par exact-time alarm guarantee nahi hota. Reliable background alarm ke liye Android APK use karein.
- Data abhi device ke local storage mein save hota hai. Online cloud sync/login server included nahi hai.
  Backup/Restore JSON export-import se kiya ja sakta hai.
- Ye starter app hai; Play Store publishing, server sync, user accounts aur testing alag steps hain.
