package com.mydailyroutine.app;

import android.app.*;
import android.content.*;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context c, Intent i) {
    String title=i.getStringExtra("title"); String note=i.getStringExtra("note");
    NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
    if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel("routine_reminders","Routine reminders",NotificationManager.IMPORTANCE_HIGH));
    Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"routine_reminders"):new Notification.Builder(c);
    b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title==null?"MY DAILY ROUTINE":title).setContentText(note==null?"Time for your task":note).setAutoCancel(true);
    nm.notify((int)(System.currentTimeMillis()%Integer.MAX_VALUE),b.build());
  }
}
