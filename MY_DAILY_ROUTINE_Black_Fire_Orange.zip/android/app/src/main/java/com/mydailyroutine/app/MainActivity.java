package com.mydailyroutine.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.webkit.*;
import android.view.*;
import java.util.Calendar;

public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
      requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 44);
    web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.setWebChromeClient(new WebChromeClient());
    web.addJavascriptInterface(new AlarmBridge(this), "AndroidAlarm");
    setContentView(web);
    web.loadUrl("file:///android_asset/www/index.html");
  }
  @Override public void onBackPressed() { if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }

  public static class AlarmBridge {
    Context c; AlarmBridge(Context c){this.c=c;}
    @JavascriptInterface public void schedule(long millis, String title, String note) {
      Intent i=new Intent(c,AlarmReceiver.class); i.putExtra("title",title); i.putExtra("note",note);
      PendingIntent pi=PendingIntent.getBroadcast(c,(int)(millis%Integer.MAX_VALUE),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
      AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
      if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi);
      else am.setExact(AlarmManager.RTC_WAKEUP,millis,pi);
    }
  }
}
