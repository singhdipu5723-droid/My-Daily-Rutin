Copy the contents of the web/ folder into this directory before building Android APK.
